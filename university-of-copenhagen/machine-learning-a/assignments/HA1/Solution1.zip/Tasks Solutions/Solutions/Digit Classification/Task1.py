import os
import numpy as np
import matplotlib.pyplot as plt 

# Ensure output directory exists for saved figures
os.makedirs("results", exist_ok=True)

data_file_path = "MNIST-5-6-Subset.txt"
labels_file_path = "MNIST-5-6-Subset-Labels.txt"

data_matrix = np.loadtxt(data_file_path)
labels = np.loadtxt(labels_file_path)

data_matrix = data_matrix.reshape((784, 1877), order='F') 

def convert(labels):
    return np.where(labels == 5, -1, 1)

def knn(training_points, training_labels, test_points, test_labels):
    training_labels = convert(training_labels)
    test_labels = convert(test_labels)
    m = training_points.shape[1]
    n = test_points.shape[1]
    
    diag_train = np.diag(training_points.T @ training_points).reshape(-1, 1)  # shape: (m, 1)
    diag_test  = np.diag(test_points.T @ test_points).reshape(1, -1)   # shape: (1, n)
    
    distances_matrix = (
        diag_train @ np.ones((1, n)) 
        - 2 * (training_points.T @ test_points) 
        + np.ones((m, 1)) @ diag_test
    )
    
    indices = np.argsort(distances_matrix, axis=0)
    sorted_labels = training_labels[indices]

    sum_of_labels = np.cumsum(sorted_labels, axis=0)
    predictions = np.sign(sum_of_labels)

    errors = np.mean(predictions != test_labels, axis=1)
    return errors


m = 50
n_values = [10, 20, 40, 80]
K_range = np.arange(1, m + 1)

# Dictionary where we save the variance for each n
variances = {}

X_train = data_matrix[:, :m]
y_train = labels[:m]

# 1. Generate and save validation error plots for each n
for n in n_values:
    plt.figure(figsize=(8, 5))
    validation_errors = np.zeros((5, m))
    
    for i in range(1, 6):
        start_idx = m + (i - 1) * n
        end_idx = m + i * n
        
        X_val = data_matrix[:, start_idx:end_idx]
        y_val = labels[start_idx:end_idx]
        
        # Calculate the errors for validation set i
        validation_errors[i - 1] = knn(X_train, y_train, X_val, y_val)
        
        # Plot the curve for validation set i
        plt.plot(K_range, validation_errors[i - 1], label=f'Validation Set {i}')
    
    # Calculate the variance across the 5 validation sets for each K (along axis 0)
    variances[n] = np.var(validation_errors, axis=0)
    
    plt.xlabel('K (Number of neighbors)')
    plt.ylabel('Validation error')
    plt.title(f'Validation Error as a Function of K for n = {n}')
    plt.legend()
    plt.grid(True)
    
    # Save figure non-blockingly and free memory
    plt.savefig(f"results/validation_error_n_{n}.png", bbox_inches='tight', dpi=300)
    plt.close()

# 2. Generate and save the aggregated variance plot
plt.figure(figsize=(8, 5))

for n in n_values:
    plt.plot(K_range, variances[n], label=f'n = {n}')

plt.xlabel('K (Number of neighbors)')
plt.ylabel('Variance of validation error')
plt.title('Variance of Validation Error Across 5 Sets as a Function of K')
plt.legend()
plt.grid(True)

plt.savefig("results/variance_vs_k.png", bbox_inches='tight', dpi=300)
plt.close()

print("Execution finished. All 5 plots saved to the 'results/' directory.")
